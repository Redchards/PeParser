// OBfister.cpp�: d�finit le point d'entr�e pour l'application console.
//

#include <stdafx.h>


int main(int argc, char* argv[])
{
	return 0;
}

